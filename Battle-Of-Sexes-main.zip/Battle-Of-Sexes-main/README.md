# Battle-Of-Sexes
This project is inspired by Chapter 9 of The Selfish Gene, a famous book by Richard Dawkins that builds upon the Adaptation and Natural Selection theory as a way of expressing the gene-centered view of evolution.


You can find the documentation of the project [here](https://github.com/cristinalakasz/Battle-Of-Sexes/blob/main/Battle%20of%20Sexes%20Paper.pdf).
